package com.br.ms.communication.buytrip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationBuyTrip {

    public static void main(String[] args) {
        SpringApplication.run(ApplicationBuyTrip.class, args);
    }

}