package com.br.ms.communication.buyfeedback.exceptions;

public class NaoFinalizadoException extends RuntimeException {

	private static final long serialVersionUID = 6786702176667097417L;

	
}
