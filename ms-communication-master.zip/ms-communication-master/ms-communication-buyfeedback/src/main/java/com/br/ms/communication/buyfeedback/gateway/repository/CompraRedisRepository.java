package com.br.ms.communication.buyfeedback.gateway.repository;

import com.br.ms.communication.buyfeedback.domain.CompraRedis;
import org.springframework.data.repository.CrudRepository;

public interface CompraRedisRepository extends CrudRepository<CompraRedis, String> {

}
